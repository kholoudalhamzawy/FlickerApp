//
//  FlickrService.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 18/04/2025.
//

import Foundation
import Combine

struct FlickrService {
    enum FlickrError: Error {
        case path
        case url
        case error(_ text: String)
    }

    private var path: String { "https://api.flickr.com/services/rest" }

    // Helper method (DO NOT MODIFY)
    func buildUrl(searchQuery: String, page: Int) throws -> URL {
        guard var components = URLComponents(string: path)
        else { throw FlickrError.path }
        components.queryItems = [
            URLQueryItem(name: "text", value: searchQuery),
            URLQueryItem(name: "method", value: "flickr.photos.search"),
            URLQueryItem(name: "api_key", value: "a724969f016f0b8badd7e518a6c48e55"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "safe_search", value: "1"),
            URLQueryItem(name: "extras", value: "url_t"),
            URLQueryItem(name: "nojsoncallback", value: "1"),
            URLQueryItem(name: "page", value: "\(page)")
            
        ]
        guard let url = components.url
        else { throw FlickrError.url }
        return url
    }
    
    
    func download(url: URL)-> AnyPublisher<Data, Error> {
        
        URLSession.shared.dataTaskPublisher(for: url)
            .tryMap {  Data, response in
                
                guard let response = response as? HTTPURLResponse, response.statusCode >= 200, response.statusCode < 300 else {
                    throw FlickrError.error("bad response")
                }
                return Data
            }
            .retry(3)
            
            .eraseToAnyPublisher()
    }
    
    
}
