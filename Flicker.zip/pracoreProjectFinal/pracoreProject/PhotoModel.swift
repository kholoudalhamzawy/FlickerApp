//
//  PhotoModel.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 18/04/2025.
//

import Foundation


struct PhotoModel: Codable{
    let photos: photos?
    
}


struct photos: Codable{
    let photo: [photo]?
    let page : Int?
    let pages: Int?
}

struct photo: Codable {
    let id: String?
    let title: String?
    let url_t: String?
    let height_t: Int?
    let width_t: Int?
}
