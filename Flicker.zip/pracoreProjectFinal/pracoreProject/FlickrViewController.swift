//
//  FlickrViewController.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 18/04/2025.
//

import UIKit

import Combine
final class FlickrViewController: UIViewController{
    
    private var searchController: UISearchController?
    private var flickerViewCollection: UICollectionView?
    static let cellID = String(describing: FlickrPhotoCell.self)
    private var viewModel = FlickerViewModel()
    private var cancellables = Set<AnyCancellable>()
    private var loader = UIActivityIndicatorView()

    override func viewDidLoad() {
        super.viewDidLoad()
        configureNavigationItem()
        addSearchBar()
        addCollectionView()
        bind(to: viewModel)
        setUpLoader()
    }
   
    
}

extension FlickrViewController{
    
    private func bind(to viewModel: FlickerViewModel) {
        
        viewModel.$searchText
            .debounce(for: .seconds(0.5), scheduler: DispatchQueue.main)
            .removeDuplicates()
            .sink { [weak self] in
                self?.viewModel.searcForQuery($0)
            }
            .store(in: &cancellables)
        
        viewModel.$errorText
            .filter({!$0.isEmpty})
            .sink { [weak self] in
                self?.showError($0)
            }
            .store(in: &cancellables)
        
        viewModel.$photoScreenModel
            .sink { [weak self] _ in
                self?.flickerViewCollection?.reloadData()
            }
            .store(in: &cancellables)
        
        
        viewModel.$page
            .filter({$0 > 1})
            .sink { [weak self] _ in
                self?.viewModel.searcForQuery(viewModel.searchText)

            }
            .store(in: &cancellables)
        
        viewModel.$isLoading
            .sink { [weak self]  in
                if $0 {
                    self?.loader.startAnimating()
                    self?.view.isUserInteractionEnabled = false
                } else {
                    self?.loader.stopAnimating()
                    self?.view.isUserInteractionEnabled = true
                }
                
            }
            .store(in: &cancellables)
        

    }
    
    private func showError(_ error: String){
        
        let alert = UIAlertController(title: "Error", message: error, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            self?.searchController?.searchBar.text = ""
        }
        alert.addAction(action)
        present(alert, animated: true)
    }
    
    func setUpLoader(){
        loader.style = .large
        loader.center = view.center
        loader.hidesWhenStopped = true
        view.addSubview(loader)
    }
    
    
}

extension FlickrViewController: UICollectionViewDelegate , UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            viewModel.photoScreenModel.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            if let cell = flickerViewCollection?.dequeueReusableCell(withReuseIdentifier: FlickrViewController.cellID, for: indexPath) as? FlickrPhotoCell {
                
                let item = viewModel.photoScreenModel[indexPath.item]
                
                cell.configure(titleName: item.title ?? "",
                               titlesubName: "\(item.height_t ?? 0) * \(item.width_t ?? 0)",
                               url: item.url_t ?? "",
                               id: item.id ?? "")
                
                if viewModel.photoScreenModel.count > 4, indexPath.item == viewModel.photoScreenModel.count - 4 {
                    self.viewModel.page += 1
                }
                
                return cell
            }
            return UICollectionViewCell()
        }
    
}

extension FlickrViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if let text = searchController.searchBar.text {
            viewModel.searchText = text
        }
    }
}

// Convenience methods to setup your view
private extension FlickrViewController {
    func configureNavigationItem() {
        navigationItem.title = NSLocalizedString("Flickr Challenge", comment: "main grid title")
        navigationItem.hidesSearchBarWhenScrolling = false
    }

    func addSearchBar() {
        self.searchController = makeSearchController()
        searchController?.searchResultsUpdater = self
        navigationItem.searchController = searchController
    }

    func makeSearchController() -> UISearchController {
          let searchController = UISearchController()
          searchController.searchBar.showsSearchResultsButton = false
          searchController.searchBar.returnKeyType = .done
          searchController.searchBar.showsCancelButton = false
          searchController.hidesNavigationBarDuringPresentation = false
          return searchController
      }

    func addCollectionView() {
        let collectionView = FlickerCollectionView()
        self.flickerViewCollection = collectionView
        self.flickerViewCollection?.delegate = self
        self.flickerViewCollection?.dataSource = self

        // when cells was programatically created
        collectionView.register(UINib(nibName: "FlickrPhotoCell", bundle: nil), forCellWithReuseIdentifier: Self.cellID)

        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            view.safeAreaLayoutGuide.topAnchor.constraint(equalTo: collectionView.topAnchor),
            view.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: collectionView.bottomAnchor),
            view.leadingAnchor.constraint(equalTo: collectionView.leadingAnchor),
            view.trailingAnchor.constraint(equalTo: collectionView.trailingAnchor)
        ])
    }
}

// OPTIONAL: Collection View subclass with a custom layout
final class FlickerCollectionView: UICollectionView {
    convenience init() {
        self.init(
            frame: CGRect.zero,
            collectionViewLayout: Self.makeCollectionViewLayout()
        )
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        self.collectionViewLayout = Self.makeCollectionViewLayout()
    }

    private static func makeCollectionViewLayout() -> UICollectionViewLayout {
        let itemSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.32),
            heightDimension: .fractionalHeight(1)
        )

        let item = NSCollectionLayoutItem(layoutSize: itemSize)

        let groupSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1),
            heightDimension: .fractionalWidth(0.32)
        )

        let group = NSCollectionLayoutGroup.horizontal(
            layoutSize: groupSize,
            subitems: [item]
        )
        group.interItemSpacing = .flexible(6)

        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 6
        return UICollectionViewCompositionalLayout(section: section)
    }
}
