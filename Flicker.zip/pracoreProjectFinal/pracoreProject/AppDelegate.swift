//
//  AppDelegate.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 18/04/2025.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        var windowScene = UIWindow(frame: UIScreen.main.bounds)
        let vc = FlickrViewController()
        let rootVC = UINavigationController(rootViewController: vc)
        windowScene.rootViewController = rootVC
        window = windowScene
        window?.makeKeyAndVisible()
        
        return true
    }


}

