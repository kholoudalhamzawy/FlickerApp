//
//  FlickerViewModel.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 21/04/2025.
//

import Foundation
import Combine

class FlickerViewModel {
    
    private var flickerService = FlickrService()
    
    @Published var photoScreenModel: [photo] = []
    private var cancellables = Set<AnyCancellable>()
    @Published var searchText: String = ""
    @Published var errorText: String = ""
    @Published var page: Int = 1
    @Published var isLoading: Bool = false

    
    func searcForQuery(_ text: String) {
        
        guard !text.isEmpty else {
            photoScreenModel = []
            imageCacheManager.instanse.clearCache()
            fileManager.instance.clearFolder(in: "photoFlicker")
            return
        }
        do {
            isLoading = true

            let url = try flickerService.buildUrl(searchQuery: text, page: page)
            flickerService.download(url: url)
                .decode(type: PhotoModel.self, decoder: JSONDecoder())
                .receive(on: DispatchQueue.main)
                .sink { [weak self] completion in
                    switch completion {
                    case .finished:
                        self?.isLoading = false
                        return
                    case .failure(let error):
                        self?.isLoading = false
                        self?.errorText = (error.localizedDescription)

                        return
                    }
                } receiveValue: { [weak self] PhotoModel in
                    if let pics = PhotoModel.photos?.photo {
                        guard let self else {return}
                        
                        self.photoScreenModel.append(contentsOf: pics)
                        
                        if self.page == PhotoModel.photos?.pages ?? 1  {
                            self.page = 1
                        }
                    }
                }
                .store(in: &cancellables)
            
            
        } catch {
            self.errorText = (error.localizedDescription)
            
        }
    }
    
    
}
