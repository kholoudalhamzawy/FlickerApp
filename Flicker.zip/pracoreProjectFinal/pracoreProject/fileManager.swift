//
//  fileManager.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 21/04/2025.
//

import Foundation
import UIKit

final class fileManager {
    
    static let instance = fileManager()
    private init(){}
    
    func getFileURL(for fileName: String)-> URL?{
        
        return FileManager.default.urls(for: .cachesDirectory, in: .allDomainsMask).first?.appendingPathComponent(fileName) ?? nil
    }
    
    func createDirecifNeeded(for fileName: String){
        if let url = getFileURL(for: fileName){
            
            if !FileManager.default.fileExists(atPath: url.path) {
                do {
                    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
                    print (" created \(fileName) ")

                } catch let error {
                    print ("error creating \(fileName) for error ")
                }
            }
        }}
    
    
    func saveImage(_ image: UIImage, in folder: String, imageName: String ){
        
        createDirecifNeeded(for: folder)
        
        let imageData = image.jpegData(compressionQuality: 1.0)
        
        if let imgUrl = getImgURL(in: folder, imageName: imageName){
            if !FileManager.default.fileExists(atPath: imgUrl.path) {
                
                do {
                    try imageData?.write(to: imgUrl)

                } catch let error {
                    print ("error saving  for error \(error)")
                }
            }
            
        }
        
        
    }
    
    func clearFolder(in folder: String){
        
        
        if let folderUrl = getFileURL(for: folder){
            if FileManager.default.fileExists(atPath: folderUrl.path) {
                do {
                   
                    try FileManager.default.removeItem(at: folderUrl)
                } catch let error {
                    print ("error clearing \(folderUrl) for error ")
                }
            }
            
        }
        
        
    }
    func getPhoto(in folder: String, imageName: String) -> UIImage?{
        
        if let imgUrl = getImgURL(in: folder, imageName: imageName){
            if FileManager.default.fileExists(atPath: imgUrl.path) {
                return UIImage(contentsOfFile: imgUrl.path)
            }
        }
        return nil
    }
    
    
    func getImgURL(in fileName: String, imageName:  String)-> URL?{
        
        return FileManager.default.urls(for: .cachesDirectory, in: .allDomainsMask).first?.appendingPathComponent(fileName).appendingPathComponent(imageName) ?? nil
    }
    
}
