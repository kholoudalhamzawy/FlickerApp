//
//  FlickrPhotoCell.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 18/04/2025.
//

import UIKit
import Combine

class FlickrPhotoCell: UICollectionViewCell {
    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var callImage: UIImageView!
    @IBOutlet weak var subtitle: UILabel!
    
    private var photoManager: PhotoManager? = nil
    private var cancellables = Set<AnyCancellable>()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(titleName: String, titlesubName: String, url: String, id: String){
        title.text = titleName
        subtitle.text = titlesubName
        photoManager = .init(url: url, id: id)
        photoManager?.$managerImage
            .receive(on: RunLoop.main)
            .sink(receiveValue: {[weak self] in
                self?.callImage.image = $0
            })
            .store(in: &cancellables)
    }
}
