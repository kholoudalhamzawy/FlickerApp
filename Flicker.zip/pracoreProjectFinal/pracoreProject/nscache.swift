//
//  nscache.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 21/04/2025.
//

import Foundation
import UIKit


final class imageCacheManager {
    
    static let instanse = imageCacheManager()
    private init ()
    {}
    private var cache = NSCache<NSString, UIImage>()
  
     func getImage(for key: String)-> UIImage? {
        return cache.object(forKey: key as NSString) ?? nil
    }
     func setImage(_ image: UIImage, for key: String){
        cache.setObject(image, forKey: key as NSString)
    }
     func clearCache(){
        cache.removeAllObjects()
    }
}






//
// final class AppCache {
//    
//    private let cache = NSCache<NSString, UIImage>()
//    
//    private final class CacheEntry {
//       let value: Value
//           
//     init(value: Value) {
//         self.value = value
//     }
//    }AppCache
//
//   
//    func insert(_ value: Value, forKey key: String) {
//        let entry = CacheEntry(value: value)
//        cache.setObject(entry, forKey: key as NSString)
//    }
//
//    func value(forKey key: String) -> Value? {
//        guard let entry = cache.object(forKey: KeyWrapper(key)) else { return nil }
//        return entry.value
//    }
//
//    func removeValue(forKey key: Key) {
//        cache.removeObject(forKey: KeyWrapper(key))
//    }
//    
//}
//
//import Foundation
//
//protocol DefaultComicsCache {
//    func getCachedComics() -> [ComicResponseDTO]?
//    func getCachedDetails(id: Int) -> AppResponseDTO<ComicDetailsResponseDTO>?
//}
//
//class ComicsCache: DefaultComicsCache{
//    
//    static let shared: ComicsCache = .init()
//
//    private let comicsCache = AppCache<String,[ComicResponseDTO]>()
//    private let detailsCache = AppCache<String, AppResponseDTO<ComicDetailsResponseDTO>>()
//    
//    
//    func cacheComics(comics: [ComicResponseDTO]) {
//        comicsCache.insert(comics, forKey: "ComicsCache")
//    }
//
//    func getCachedComics() -> [ComicResponseDTO]? {
//        return comicsCache.value(forKey: "ComicsCache")
//    }
//    
//    func cacheComicsDetails(id: Int, comic: AppResponseDTO<ComicDetailsResponseDTO>) {
//        detailsCache.insert(comic, forKey: "ComicsCacheDetails" + "\(id)")
//        }
//
//    func getCachedDetails(id: Int) -> AppResponseDTO<ComicDetailsResponseDTO>? {
//        return detailsCache.value(forKey: "ComicsCacheDetails" + "\(id)")
//    }
//
//}
