//
//  PhotoMadel.swift
//  pracoreProject
//
//  Created by kholoud alhamzawy on 21/04/2025.
//

import Foundation
import UIKit
import Combine

class PhotoManager {
    
    private var apiservice: FlickrService
    private var url: String
    private var id: String // caching
    @Published var managerImage: UIImage?
    private var cancellables = Set<AnyCancellable>()
    
    
    init(apiservice: FlickrService = FlickrService(), url: String, id: String, image: UIImage? = UIImage(systemName: "photo")) {
        self.apiservice = apiservice
        self.url = url
        self.id = id
        self.managerImage = image
        
//        if let cachedImage = imageCacheManager.instanse.getImage(for: url){
        if let cachedImage = fileManager.instance.getPhoto(in: "photoFlicker", imageName: id) {
            self.managerImage = cachedImage
            print("cashed")
        } else {
            self.downloadImage()
            print("download")

        }

    }
    
    func downloadImage() {
        if let urlString = URL(string: url){
            apiservice.download(url: urlString)
                .map({UIImage(data: $0)})
                .receive(on: RunLoop.main)
                .replaceError(with: UIImage(systemName: "photo"))
                .sink(receiveValue: { [weak self] image in
                    self?.managerImage = image
                    if let image = image, let url = self?.url, let id = self?.id {
//                        imageCacheManager.instanse.setImage(image, for: url)
                        fileManager.instance.saveImage(image, in: "photoFlicker", imageName: id)
                    }
                })
                .store(in: &cancellables)
            
        } else {
            print("bad Image URL")
            managerImage = UIImage(systemName: "photo")
        }
    }
    
    
}
